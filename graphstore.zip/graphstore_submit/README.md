
./graph_bm -t PR -maxiters 5 -f [filename]
./graph_bm -t BFS -src [src] -f [filename]
./graph_bm -t CC -f [filename]

